using NUnit.Framework;
using System;
using CS422;
using System.IO;

namespace StreamTests
{
	[TestFixture()]
	public class ConcatStreamTests
	{
		[Test()]
		public void TestCase1 ()
		{
			byte[] buffer1 = new byte[1024];
			MemoryStream ms1 = new MemoryStream (buffer1);
			byte[] buffer2 = new byte[1024];
			NoSeekMemoryStream nsms2 = new NoSeekMemoryStream (buffer2);

			ConcatStream cs = new ConcatStream (ms1,nsms2);
			Assert.AreNotSame (cs, null);
		}


		[Test()]
		public void TestCase2a ()
		{
			byte[] buffer1 = new byte[1024];
			byte[] buffer2 = new byte[1024];
			for (int i = 0; i < 1024; i++)
			{
				buffer1 [i] = 0x20;
				buffer2 [i] = 0x20;
			}

			MemoryStream ms1 = new MemoryStream (buffer1);
			MemoryStream ms2 = new MemoryStream (buffer2);
			ConcatStream cs = new ConcatStream (ms1,ms2);

			cs.Seek (0, SeekOrigin.End);

			Assert.AreEqual (ms1.Length, ms1.Position);

		}

		[Test()]
		public void TestCase2b ()
		{
			byte[] buffer1 = new byte[1024];
			byte[] buffer2 = new byte[1024];
			for (int i = 0; i < 1024; i++)
			{
				buffer1 [i] = 0x20;
				buffer2 [i] = 0x20;
			}
			MemoryStream ms2 = new MemoryStream (buffer2);
			MemoryStream ms1 = new MemoryStream (buffer1);

			ConcatStream cs = new ConcatStream (ms1,ms2);

			cs.Seek (0, SeekOrigin.End);

			Assert.AreEqual (ms2.Length, ms2.Position);
		}

		[Test()]
		public void WriteTest ()
		{
			byte[] buffer1 = new byte[1024];
			byte[] buffer2 = new byte[1024];
			for (int i = 0; i < 1024; i++)
			{
				buffer1 [i] = 0x20;
				buffer2 [i] = 0x22;
			}
			MemoryStream ms1 = new MemoryStream (buffer1);
			MemoryStream ms2 = new MemoryStream (buffer2);


			ConcatStream cs = new ConcatStream (ms1,ms2);
			cs.Write (buffer2, 0, 1024);

			byte[] readbuffer1 = new byte[1024];
			byte[] readbuffer2 = new byte[1024];
			cs.Seek (0, SeekOrigin.Begin);
			cs.Read (readbuffer1, 0, 1024);
			cs.Read (readbuffer2, 0, 1024);
			cs.Seek (0, SeekOrigin.Begin);
			cs.Seek (0, SeekOrigin.End);

			Assert.AreEqual (cs.Length, cs.Position);
		}

	}

	[TestFixture()]
	public class NoSeekMemoryStreamTests
	{
		[Test()]
		public void TestCase1 ()
		{
			byte[] buffer = new byte[1024];
			NoSeekMemoryStream nsms = new NoSeekMemoryStream (buffer);
			Assert.AreNotSame (nsms, null);
		}

		[Test()]
		public void TestCase2 ()
		{
			byte[] buffer = new byte[1024];
			NoSeekMemoryStream nsms = new NoSeekMemoryStream (buffer);
			Exception expected = new NotImplementedException();
			try {
				nsms.Seek (3, SeekOrigin.Begin);
			} catch (Exception ex) {
				expected = ex;
			}
			Assert.AreEqual ("Operation is not supported.",expected.Message);
		}
	}
}

